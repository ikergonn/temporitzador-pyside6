"""Permite iniciar el gestor con: python -m gestor_incidencies."""

from .main import run

if __name__ == "__main__":
    raise SystemExit(run())
