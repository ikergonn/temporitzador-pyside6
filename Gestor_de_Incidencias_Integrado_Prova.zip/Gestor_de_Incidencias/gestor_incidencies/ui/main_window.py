from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QMainWindow,
    QMessageBox,
)

from ..models import Incident, IncidentFilters, Status
from ..services import IncidentService, IncidentValidationError
from ..qt_models import IncidentTableModel
from .dialogs import IncidentDialog
from .ui_prova import Ui_MainWindow


class MainWindow(QMainWindow):
    """Finestra visual de Prova connectada al servei persistent del gestor."""

    def __init__(self, service: IncidentService) -> None:
        super().__init__()
        self.service = service
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Gestor de incidencias")

        self.model = IncidentTableModel()
        self.ui.tableView.setModel(self.model)
        self.ui.tableView.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self.ui.tableView.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )
        self.ui.tableView.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self.ui.tableView.setAlternatingRowColors(True)
        self.ui.tableView.verticalHeader().setVisible(False)
        self.ui.tableView.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )

        self.ui.pushButton_3.setText("Nueva incidencia")
        self.ui.pushButton_2.setText("Editar incidencia")
        self.ui.pushButton.setText("Eliminar incidencia")
        self.ui.pushButton_3.setObjectName("btnNueva")
        self.ui.pushButton_2.setObjectName("btnEditar")
        self.ui.pushButton.setObjectName("btnEliminar")

        self.ui.pushButton_3.clicked.connect(self.create_incident)
        self.ui.pushButton_2.clicked.connect(self.edit_selected)
        self.ui.pushButton.clicked.connect(self.delete_selected)
        self.ui.actionAbrir.triggered.connect(self.refresh)
        self.ui.actionCerrar.triggered.connect(self.close)

        style_path = Path(__file__).with_name("prova.qss")
        if style_path.exists():
            self.setStyleSheet(style_path.read_text(encoding="utf-8"))

        self.refresh()

    def refresh(self) -> None:
        self.model.update_incidents(self.service.list_incidents())
        self.ui.statusbar.showMessage(
            f"{self.model.rowCount()} incidencias registradas"
        )

    def selected_incident(self) -> Incident | None:
        index = self.ui.tableView.currentIndex()
        if not index.isValid():
            return None
        return self.model.incident_at(index.row())

    def create_incident(self) -> None:
        dialog = IncidentDialog(self)
        if dialog.exec() != IncidentDialog.Accepted:
            return
        try:
            payload = dialog.payload()
            incident = self.service.create_incident(
                title=str(payload["title"]),
                description=str(payload["description"]),
                category=str(payload["category"]),
                priority=payload["priority"],
                assignee=str(payload["assignee"]),
                due_date=str(payload["due_date"]),
                tags=list(payload["tags"]),
            )
            if payload["status"] != Status.OPEN:
                self.service.change_status(incident.id, payload["status"])
        except (IncidentValidationError, ValueError) as exc:
            QMessageBox.warning(self, "Validación", str(exc))
            return
        self.refresh()
        QMessageBox.information(
            self, "Incidencia creada", "La incidencia se ha creado correctamente."
        )

    def edit_selected(self) -> None:
        incident = self.selected_incident()
        if incident is None:
            QMessageBox.information(
                self, "Editar incidencia", "Selecciona una incidencia para editarla."
            )
            return
        dialog = IncidentDialog(self, incident)
        if dialog.exec() != IncidentDialog.Accepted:
            return
        try:
            self.service.update_incident(incident.id, **dialog.payload())
        except (IncidentValidationError, ValueError) as exc:
            QMessageBox.warning(self, "Validación", str(exc))
            return
        self.refresh()

    def delete_selected(self) -> None:
        incident = self.selected_incident()
        if incident is None:
            QMessageBox.information(
                self, "Eliminar incidencia", "Selecciona una incidencia para eliminarla."
            )
            return
        answer = QMessageBox.question(
            self,
            "Confirmar eliminación",
            f"¿Seguro que quieres eliminar la incidencia {incident.id}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.service.delete_incident(incident.id)
        self.refresh()
