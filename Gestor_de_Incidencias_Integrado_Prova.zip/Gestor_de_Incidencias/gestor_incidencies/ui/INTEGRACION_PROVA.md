# Integración de la interfaz Prova

La ventana `ui_prova.py` y el diseño `prova.ui` proceden del proyecto ProyectoProva.
La ventana se conecta desde `main_window.py` al modelo y al servicio del Gestor de
Incidencias. La persistencia sigue gestionándose desde `repository.py`.
