# Wireframes de baixa fidelitat


## Idea clau

Un wireframe es una representacio esquematica d'una pantalla. Serveix per decidir estructura, jerarquia i relacio entre elements abans de treballar l'aspecte visual.

Pot ser:

- una pagina de Figma amb caixes i etiquetes;
- un dibuix simple;
- una taula estructurada;
- una descripcio textual amb zones i controls;
- una captura d'un esquema de baixa fidelitat.

L'eina no es l'objectiu. L'objectiu es justificar la pantalla.

## Diagrama de treball

```mermaid
%% primer_element_informat: true
flowchart TD
  A[Arquitectura navegacio i accions] --> B[Tasca de la persona usuaria]
  B --> C[Pantalla necessaria]
  C --> D[Zones funcionals]
  D --> E[Controls]
  E --> F[Tipus de control adequat]
  F --> G[Wireframe coherent]
  G --> H[Base per definir el sistema visual]
```

Llegeix el diagrama de dalt a baix: primer recuperes l’arquitectura i la tasca, després decideixes quina pantalla és necessària i finalment distribueixes els controls. El llistat, el detall i el formulari són tres casos de treball, no tres peces amb un ordre que s’hagi d’endevinar.

## Que ha de mostrar

Un wireframe d’aquesta unitat ha de mostrar:

| Element | Pregunta que respon |
| --- | --- |
| Titol o context | On es la persona usuaria? |
| Zona de contingut principal | Quina informacio necessita per completar la tasca? |
| Accio principal | Que ha de poder fer de manera evident? |
| Accions secundaries | Que pot fer, pero no es el centre de la tasca? |
| Controls d'entrada o filtre | Quines dades pot introduir o modificar? |
| Navegacio o retorn | Com continua o torna enrere? |

## Baixa fidelitat

Baixa fidelitat vol dir que encara no cal definir:

- colors finals;
- tipografies finals;
- icones definitives;
- separacions exactes en pixels;
- components reals de Qt, PySide6 o una altra llibreria.

Si el filtre d'estat afecta el llistat, ha d'apareixer prop del llistat. Si una accio afecta una incidencia concreta, ha d'estar prop d'aquesta incidencia.

## Pantalles minimes

Per al `gestor-incidencies`, treballarem com a minim:

| Pantalla | Tasca principal |
| --- | --- |
| Llistat d'incidencies | Consultar, filtrar i obrir incidencies. |
| Detall d'incidencia | Revisar informacio i executar accions contextuals. |
| Formulari d'alta o edicio | Introduir o modificar dades d'una incidencia. |
