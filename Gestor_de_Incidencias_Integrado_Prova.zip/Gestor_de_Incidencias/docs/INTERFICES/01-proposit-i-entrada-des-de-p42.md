# Propòsit i entrada des de la unitat «Organitzar la informació, la navegació i les accions»

El rol B transforma en pantalles de baixa fidelitat les decisions de navegació que ja ha validat l'equip. Un wireframe no és una pantalla final: és un esquema per decidir zones, informació, accions i controls abans d'aplicar-hi una capa visual.

## Entrada compartida

| Decisió disponible | Paper en els wireframes |
| --- | --- |
| Arquitectura d'informació | Determina quines pantalles formen part del recorregut. |
| Flux principal | Dona l'ordre de pantalles i retorns. |
| Menú o navegació global | Identifica accions persistents o d'accés general. |
| Mapa d'accions | Separa accions globals, principals i contextuals. |
| Accions de risc | Assenyala controls que requeriran confirmació o protecció. |

Sense aquesta entrada, el wireframe seria una suposició visual i no una decisió compartida.

## Representació

Figma és l'eina seleccionada per construir els wireframes. Caixes, etiquetes, zones, fletxes i notes curtes són suficients mentre facin visibles les decisions. Una representació amb taules, dibuixos o esquemes textuals és equivalent si permet revisar zones, controls i justificacions.

## Pregunta guia

> Com es distribueixen pantalles i controls perquè cada tasca del `gestor-incidencies` sigui clara, coherent i fàcil d'executar?

## Relleu del rol B

El llistat, el detall, el formulari, l'inventari de controls i les justificacions passen al rol C. El sistema visual hi aporta llegibilitat, estats i missatges sense tornar a definir-ne l'arquitectura.

## Límit

Aquesta unitat treballa `CE5` i `CE6`. El color, la tipografia, les icones finals, els missatges definitius i la prova d'usabilitat pertanyen als trams posteriors del recorregut.

## Referències per ampliar

- [Nielsen Norman Group: wireframes](https://www.nngroup.com/articles/wireframes/)
- [W3C WAI: etiquetes i instruccions](https://www.w3.org/WAI/WCAG22/Understanding/labels-or-instructions.html)
- [Material Design: components](https://m3.material.io/components)
