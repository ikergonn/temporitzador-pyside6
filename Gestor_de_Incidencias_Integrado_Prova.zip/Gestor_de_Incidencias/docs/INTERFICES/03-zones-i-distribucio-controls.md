# Zones i distribucio de controls


## Zones funcionals

Abans de triar controls concrets, l'equip descriu la pantalla en zones funcionals.

| Zona | Funcio |
| --- | --- |
| Capcalera o context | Identifica pantalla, estat o seccio. |
| Navegacio | Permet canviar de seccio o tornar. |
| Accions principals | Mostra l'accio mes important de la pantalla. |
| Filtres o cerca | Permet reduir o ordenar informacio. |
| Contingut principal | Mostra dades o registres centrals. |
| Accions contextuals | Actuen sobre un element concret. |
| Ajuda o informacio auxiliar | Dona suport sense interrompre la tasca. |

No totes les pantalles necessiten totes les zones. La distribucio ha de respondre a la tasca.

## Distribuir no es decorar

Distribuir controls vol dir decidir on apareixen perque la persona usuaria pugui completar la tasca.

| Decisio | Criteri |
| --- | --- |
| Filtres damunt del llistat | Modifiquen els resultats visibles. |
| Boto `Nova incidencia` destacat | Inicia una tasca frequent. |
| Accions de fila dins del registre | Afecten una incidencia concreta. |
| `Cancel.lar` prop de `Guardar`, pero amb menor pes | Permet sortir sense confondre-la amb l'accio principal. |
| Confirmacio per canvi d'estat critic | Redueix risc d'error. |

## Jerarquia

En una pantalla, no tot pot tenir el mateix pes.

La proposta de wireframe diferencia elements:

- essencials per completar la tasca;
- utils pero secundaris;
- contextuals;
- de risc;
- informatius.

La jerarquia ha de ser visible en l'estructura del wireframe, encara que no defineixis colors finals.

## Comprovació compartida

Abans de concretar els controls, l'equip contrasta cada pantalla:

- La tasca principal es visible sense explicar-la oralment?
- Els controls que modifiquen una zona estan prop d'aquesta zona?
- Les accions de risc estan protegides o separades?
- Les accions secundaries no competeixen amb l'accio principal?
- Es pot navegar o tornar sense perdre el context?

## Preparacio per la unitat «Definir el sistema visual i els missatges»

«Definir el sistema visual i els missatges» aplicara llegibilitat i sistema visual sobre aquesta estructura. Si «Crear wireframes i escollir els controls» no esta ben resolt, el color i la tipografia nomes amagaran el problema.
