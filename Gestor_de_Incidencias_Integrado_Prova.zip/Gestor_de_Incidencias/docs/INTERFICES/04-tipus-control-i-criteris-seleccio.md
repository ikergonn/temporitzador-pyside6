# Tipus de control i criteris de seleccio


## Triar el control adequat

Un control es adequat quan ajuda a introduir, consultar o modificar una dada amb el minim risc d'error.

No es tria un control perque sembli modern, sino perque encaixa amb:

- el tipus de dada;
- la quantitat d'opcions;
- la frequencia d'us;
- el risc de la decisio;
- la necessitat de validar o confirmar;
- la claredat per a la persona usuaria.

## Controls habituals

| Control | Us adequat |
| --- | --- |
| Camp de text | Dades obertes i breus, com titol. |
| Area de text | Text llarg, com descripcio o observacio. |
| Selector desplegable | Una opcio entre una llista limitada. |
| Botons d'opcio | Una opcio entre poques alternatives visibles. |
| Casella de seleccio | Valor boolea o activacio independent. |
| Selector de data | Dades de calendari. |
| Taula o llistat | Col.leccio de registres comparables. |
| Pestanyes | Subapartats equivalents dins d'un mateix context. |
| Dialeg | Confirmacio, edicio puntual o accio que interromp el flux. |
| Boto d'ordre | Execucio d'una accio clara. |

## Exemples del projecte

| Dada o accio | Control possible | Justificacio |
| --- | --- | --- |
| Titol de la incidencia | Camp de text | Es una dada breu i oberta. |
| Descripcio | Area de text | Pot requerir diverses linies. |
| Prioritat | Selector o botons d'opcio | Te opcions limitades i rellevants. |
| Estat | Selector o accio contextual | Representa una fase controlada. |
| Data limit | Selector de data | Redueix errors de format. |
| Responsable | Selector o cerca | Depen del nombre de persones possibles. |
| Llistat d'incidencies | Taula o llista | Permet comparar registres. |
| Canviar estat critic | Boto amb confirmacio | Pot tenir consequencia sobre el seguiment. |

## Laboratori ràpid

El laboratori de l'equip relaciona un cas conegut amb decisions transferibles:

| Aplicacio | Que observar |
| --- | --- |
| Gmail | Llistat, seleccio, accions massives i accions contextuals. |
| Wallapop | Filtres, cards, detall i formulari de publicacio. |
| Spotify | Controls persistents, llistes i accions principals visibles. |

La pregunta no es "com ho copiem?", sino "quina decisio de control o distribucio ens ajuda en el gestor?".

## Preguntes de justificació

Per cada control important, la justificació compartida informa:

- Quina dada o accio representa?
- Quines alternatives tenia?
- Per que aquest control redueix error o millora claredat?
- Que passara si la dada es obligatoria, buida o incorrecta?
- Aquest control es coherent amb altres pantalles?

No cal escriure encara el missatge final d'error. Aixo vindra en la unitat «Definir el sistema visual i els missatges».
