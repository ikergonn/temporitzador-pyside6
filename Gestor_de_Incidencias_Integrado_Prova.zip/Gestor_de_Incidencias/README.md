# Gestor de Incidencias

Aplicación de escritorio para gestionar incidencias, desarrollada con Python y PySide6. La interfaz visual está basada en el proyecto Prova y utiliza el modelo, los servicios, el almacenamiento JSON y las pruebas del Gestor de Incidencias.

## Abrir en Visual Studio Code

1. Descomprime este ZIP.
2. En VS Code, selecciona **Archivo > Abrir carpeta** y abre `Gestor_de_Incidencias`.
3. Abre la terminal integrada (**Terminal > Nuevo terminal**).

## Crear el entorno virtual en Windows

El directorio `.venv` está reservado en la estructura del proyecto. Para crear dentro de él un entorno virtual real y compatible con tu Windows, ejecuta una sola vez:

```powershell
py -m venv .venv
```

Actívalo:

```powershell
.\.venv\Scripts\Activate.ps1
```

Instala las dependencias:

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
```

> El entorno virtual real se crea en tu propio Windows. No se puede trasladar dentro de un ZIP desde otro sistema operativo porque contiene ejecutables y rutas específicas de cada equipo. Por eso el ZIP incluye la carpeta `.venv` como espacio reservado, no un entorno falso o incompatible.

## Ejecutar la aplicación

Desde la raíz del proyecto, con `.venv` activo:

```powershell
python -m gestor_incidencies
```

También puedes ejecutar directamente:

```powershell
python -m gestor_incidencies.main
```

## Ejecutar pruebas

```powershell
python -m pytest -v
```

## Estructura

```text
Gestor_de_Incidencias/
├── .venv/                  # entorno virtual local de Windows
├── .vscode/
│   └── settings.json
├── gestor_incidencies/
│   ├── __init__.py
│   ├── __main__.py
│   ├── main.py
│   ├── app.py
│   ├── models.py
│   ├── repository.py
│   ├── services.py
│   ├── qt_models.py
│   ├── data/
│   ├── resources/
│   ├── tests/
│   └── ui/
├── docs/
├── requirements.txt
├── requirements-dev.txt
├── pytest.ini
├── .gitignore
└── README.md
```

## Datos

Los registros se guardan localmente en `gestor_incidencies/data/incidents.json`. La primera vez que se ejecuta, se inicializa con los datos de ejemplo de `gestor_incidencies/resources/incidents_seed.json`.

## Buenas prácticas

- Entorno virtual aislado por proyecto.
- Dependencias de ejecución y desarrollo declaradas por separado.
- `.gitignore` excluye `.venv`, cachés y archivos temporales.
- Interfaz visual de Prova integrada con la lógica de negocio del Gestor de Incidencias.\n- Separación entre interfaz, modelos, servicios y persistencia.
- Pruebas automatizadas con pytest.
- Punto de entrada de módulo: `python -m gestor_incidencies`.


## Integración de Prova

Se ha integrado la ventana visual y la hoja de estilos de `ProyectoProva` en
`gestor_incidencies/ui/`. Los botones de crear, editar y eliminar trabajan ahora
con `IncidentService` y el repositorio JSON del Gestor, por lo que los cambios
se guardan en `gestor_incidencies/data/incidents.json`. No se mantiene una
segunda aplicación independiente ni una segunda base de datos.
